<?php
session_start();

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'vsp');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// File upload paths
define('VIDEO_UPLOAD_PATH', 'uploads/videos/');
define('THUMBNAIL_UPLOAD_PATH', 'uploads/thumbnails/');

// Create upload directories if they don't exist
if (!file_exists(VIDEO_UPLOAD_PATH)) {
    mkdir(VIDEO_UPLOAD_PATH, 0777, true);
}
if (!file_exists(THUMBNAIL_UPLOAD_PATH)) {
    mkdir(THUMBNAIL_UPLOAD_PATH, 0777, true);
}

// Helper function to check if user is logged in

?>